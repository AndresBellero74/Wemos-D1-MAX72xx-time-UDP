// Use the MD_MAX72XX library to Print some text on the display
//
// Demonstrates the use of the library to print text.
//
// User can enter text on the serial monitor and this will display as a
// message on the display.

#include <MD_MAX72xx.h>
#include <SPI.h>
#include <NTPClient.h> //importamos la librería del cliente NTP
#include <ESP8266WiFi.h> //librería necesaria para la conexión wifi
#include <WiFiUdp.h> // importamos librería UDP para comunicar con 

#define PRINT(s, v) { Serial.print(F(s)); Serial.print(v); }

// Define the number of devices we have in the chain and the hardware interface
// NOTE: These pin numbers will probably not work with your hardware and may
// need to be adapted
#define HARDWARE_TYPE MD_MAX72XX::PAROLA_HW
#define MAX_DEVICES 4

#define CLK_PIN   14  // or SCK
#define DATA_PIN  13  // or MOSI
#define CS_PIN    0  // or SS

// SPI hardware interface
MD_MAX72XX mx = MD_MAX72XX(HARDWARE_TYPE, CS_PIN, MAX_DEVICES);
// Arbitrary pins
//MD_MAX72XX mx = MD_MAX72XX(HARDWARE_TYPE, DATA_PIN, CLK_PIN, CS_PIN, MAX_DEVICES);

// Text parameters
#define CHAR_SPACING  1 // pixels between characters

// Global message buffers shared by Serial and Scrolling functions
#define BUF_SIZE  75
char message[BUF_SIZE] = "Hello!";
bool newMessageAvailable = true;

// datos para conectarnos a nuestra red wifi
const char *ssid     = "Red WIFI";
const char *password = "Clave WIFI";
int Contador = 0;
//iniciamos el cliente udp para su uso con el server NTP
WiFiUDP ntpUDP;

// El Web Server se abrirá en el puerto 80
WiFiServer server(80);

// cuando creamos el cliente NTP podemos especificar el servidor al // que nos vamos a conectar en este caso
// 0.south-america.pool.ntp.org SudAmerica
// también podemos especificar el offset en segundos para que nos 
// muestre la hora según nuestra zona horaria en este caso
// restamos -10800 segundos ya que estoy en argentina. 
// y por ultimo especificamos el intervalo de actualización en
// mili segundos en este caso 6000

NTPClient timeClient(ntpUDP, "0.south-america.pool.ntp.org",-10800,6000);



void readSerial(void)
{
  static uint8_t	putIndex = 0;

  while (Serial.available())
  {
    message[putIndex] = (char)Serial.read();
    if ((message[putIndex] == '\n') || (putIndex >= BUF_SIZE-3))  // end of message character or full buffer
    {
      // put in a message separator and end the string
      message[putIndex] = '\0';
      // restart the index for next filling spree and flag we have a message waiting
      putIndex = 0;
      newMessageAvailable = true;
    }
    else
      // Just save the next char in next location
      message[putIndex++];
  }
}

void printText(uint8_t modStart, uint8_t modEnd, char *pMsg)
// Print the text string to the LED matrix modules specified.
// Message area is padded with blank columns after printing.
{
  uint8_t   state = 0;
  uint8_t   curLen;
  uint16_t  showLen;
  uint8_t   cBuf[8];
  int16_t   col = ((modEnd + 1) * COL_SIZE) - 1;
  int16_t  col2 = ((modEnd + 1) * COL_SIZE) - 1;
  int16_t  equiCol[] = {7,6,5,4,3,2,1,0,15,14,13,12,11,10,9,8,23,22,21,20,19,18,17,16,31,30,29,28,27,26,25,24};
  
  mx.control(modStart, modEnd, MD_MAX72XX::UPDATE, MD_MAX72XX::OFF);

  do     // finite state machine to print the characters in the space available
  {
    switch(state)
    {
      case 0: // Load the next character from the font table
        // if we reached end of message, reset the message pointer
        if (*pMsg == '\0')
        {
          showLen = col - (modEnd * COL_SIZE);  // padding characters
          state = 2;
          break;
        }

        // retrieve the next character form the font file
        showLen = mx.getChar(*pMsg++, sizeof(cBuf)/sizeof(cBuf[0]), cBuf);
        curLen = 0;
        state++;
        // !! deliberately fall through to next state to start displaying

      case 1: // display the next part of the character
        col--;
        //col2 = (((modEnd + 1) * COL_SIZE) - 1) - col;
        curLen++;
        mx.setColumn(equiCol[col], cBuf[curLen - 1]);
        //Serial.print("Col:");
        //Serial.print(col);
        //Serial.print(", Posicion:");
        //Serial.print(showLen - curLen);
        //Serial.print(", Caracter:");
        //Serial.print(cBuf[showLen - curLen]);
        //Serial.print(showLen);
        //Serial.print(curLen);
        //Serial.println("");
        
        // done with font character, now display the space between chars
        if (curLen == showLen)
        {
          showLen = CHAR_SPACING;
          state = 2;
        }
        break;

      case 2: // initialize state for displaying empty columns
        curLen = 0;
        state++;
        // fall through

      case 3:	// display inter-character spacing or end of message padding (blank columns)
        col--;
        //col2 = (((modEnd + 1) * COL_SIZE) - 1) - col;
        mx.setColumn(equiCol[col], 0);
        curLen++;
        if (curLen == showLen)
          state = 0;
        break;

      default:
        col = -1;   // this definitely ends the do loop
    }
  } while (col >= (modStart * COL_SIZE));

  mx.control(modStart, modEnd, MD_MAX72XX::UPDATE, MD_MAX72XX::ON);
}

void ScrollText(uint8_t modStart, uint8_t modEnd, char *pMsg)
// Print the text string to the LED matrix modules specified.
// Message area is padded with blank columns after printing.
{
  uint8_t   state = 0;
  uint8_t   curLen;
  uint16_t  showLen;
  uint8_t   cBuf[8];
  uint8_t   Palabra[320];
  uint8_t   MaxPal[32];
  int16_t   col = ((modEnd + 1) * COL_SIZE) - 1;
  int16_t  col2 = ((modEnd + 1) * COL_SIZE) - 1;
  int16_t  equiCol[] = {7,6,5,4,3,2,1,0,15,14,13,12,11,10,9,8,23,22,21,20,19,18,17,16,31,30,29,28,27,26,25,24};
  int msgLon = sizeof(*pMsg);
  int intPos = 0;
  do {
    showLen = mx.getChar(*pMsg++, sizeof(cBuf)/sizeof(cBuf[0]), cBuf);
    for ( int j = 0; showLen > j; j++) {
      Palabra[intPos] = cBuf[j];
      intPos++;
    }
  } while(*pMsg != '\0');

  msgLon = intPos;

  intPos = 0;

  col = ((modEnd + 1) * COL_SIZE) - 1;

  int msgScroll = msgLon - col;

  for (int i = 0;msgScroll > i; i++ ){
    for (int j = 0; col > j; j++){
      MaxPal[j] = Palabra[i + j];
    }
    mx.control(modStart, modEnd, MD_MAX72XX::UPDATE, MD_MAX72XX::OFF);
    for (int k = 0; col > k; k++){
       mx.setColumn(equiCol[col-k], MaxPal[k]); 
    }
    mx.control(modStart, modEnd, MD_MAX72XX::UPDATE, MD_MAX72XX::ON);
    delay(100);
  }
  
}
void setup()
{
  mx.begin();

  Serial.begin(9600);
  Serial.print("\n[MD_MAX72XX Message Display]\nType a message for the display\nEnd message line with a newline");
  WiFi.mode(WIFI_STA);
  WiFi.begin(ssid, password); // nos conectamos al wifi

// Esperamos hasta que se establezca la conexión wifi
  while ( WiFi.status() != WL_CONNECTED ) {
    delay ( 500 );
    Serial.print ( "." );
  }
 
 // Starting the web server
  server.begin();
  Serial.println("Web server ejecutándose. Esperando a la ESP IP...");
  delay(10000);
  
  Serial.println(WiFi.localIP());
  timeClient.begin(); 
  timeClient.update(); //sincronizamos con el server NTP
  Serial.println(timeClient.getFormattedTime());
}

void loop()
{
  Serial.print(WiFi.localIP());
  Serial.print("- Hora:");
  Serial.println(timeClient.getFormattedTime());
 
  delay(1000);
  // Esperando nuevas conexiones (clientes)
  WiFiClient client = server.available();
  String str = timeClient.getFormattedTime();
  String str2 = timeClient.getFormattedDate(); 

  if (client) {
    Serial.println("Nuevo cliente");
    // Boleano para localizar el fin de una solicitud http
    boolean blank_line = true;
     while (client.connected()) {
      if (client.available()) {
        char c = client.read();      
        if (c == '\n' && blank_line) {
          //Maquetación de la página con HTML
          client.println("HTTP/1.1 200 OK");
          client.println("Content-Type: text/html");
          client.println("Connection: close");
          client.println();
          // Código para mostrar la temperatura y humedad en la página
          client.println("<!DOCTYPE HTML>");
          client.println("<html>");
          client.println("<head></head><body><h1>Andres Bellero - ESP8266 - Humedad, temperatura, Hora y Aire</h1><h3>Hora: ");
          client.println(timeClient.getFormattedTime());
          //client.println("aca iria el tiempo");
          client.println("</h3>");
          
          client.println("</body>");
          client.print("<meta http-equiv=\"refresh\" content=\"1\">");  //Actualización de la página cada segundo
          client.println("</html>");
          break;  
        }
        if (c == '\n') {
          // Cuando se empieza a leer una nueva línea
          blank_line = true;
        }
        else if (c != '\r') {
          // Cuando encuentra un caracter en la línea actual
          blank_line = false;
        }
      }
    }
    // Cerrando la conexión con el cliente
    delay(1);
    client.stop();
    Serial.println("Client disconnected.");
  }
  
  delay(30); 
  if ( Contador == 3 ) {
    int lon = sizeof(str) + sizeof(str2) + 1;
    Serial.print(str);
    Serial.print(str2);
    str = str2 + "";
    Serial.print(lon);
    for (int i=0; i<lon; i++){
      message[i] = str[i];
    }
    PRINT("\nProcesando nuevo mensaje: ", message);
    ScrollText(0, MAX_DEVICES-1, message);
    newMessageAvailable = false;
    Contador = 0;
  }
  if ( Contador == 6 ){
    int hora = timeClient.getHours();
    int minutos = timeClient.getMinutes();
    int lon = 30;
    if ( hora == 6 && minutos < 10 ){
      str = "Amanecer                                          ";
    }
    else if ( hora == 12 && minutos < 10 ){
      str = "Mediodia                                          ";
    }
    else if ( hora == 15 && minutos < 10 ){
      str = "Tarde                                             ";
    }
    else if ( hora == 20 && minutos < 10 ){
      str = "Anochecer                                         ";
    }
    else if ( hora == 0 && minutos < 10 ){
      str = "Medianoche                                        ";
    }
    else{
      str = "FBELLSAN-Informatica                              ";
    }
    Serial.print(lon);
    for (int i=0; i<lon; i++){
      message[i] = str[i];
    }
    PRINT("\nProcesando nuevo mensaje: ", message);
    ScrollText(0, MAX_DEVICES-1, message);
    newMessageAvailable = false;
    Contador = 0;
  }
  Contador++;
}
